function goToProducts() {
  alert("This will navigate to the product listing page!");
}
let cartCount = 0;

function addToCart(button) {
  cartCount++; // Increment cart count
  button.disabled = true; // Disable the button
  updateCartIcon();
}

function updateCartIcon() {
  let cartIcon = document.getElementById('cart-icon');
  cartIcon.textContent = `🛒 Cart (${cartCount})`;
}
function goToPage(page) {
  alert(`Navigating to the ${page} page!`);
}
let cart = [];

function addToCart(button, productName, price) {
  const product = cart.find(item => item.name === productName);

  if (product) {
    product.quantity++;
  } else {
    cart.push({ name: productName, price, quantity: 1 });
  }

  button.disabled = true;
  updateCart();
}

function updateCart() {
  const cartItemsDiv = document.getElementById('cart-items');
  const totalItemsSpan = document.getElementById('total-items');
  const totalCostSpan = document.getElementById('total-cost');
  const cartIcon = document.getElementById('cart-icon');

  cartItemsDiv.innerHTML = ''; // Clear current cart items
  let totalItems = 0;
  let totalCost = 0;

  cart.forEach(item => {
    totalItems += item.quantity;
    totalCost += item.price * item.quantity;

    cartItemsDiv.innerHTML += `
      <div class="cart-item">
        <span>${item.name}</span>
        <span>$${item.price}</span>
let cart = [];

function addToCart(button, productName, price) {
  const product = cart.find(item => item.name === productName);

  if (product) {
    product.quantity++;
  } else {
    cart.push({ name: productName, price, quantity: 1 });
  }

  button.disabled = true;
  updateCart();
}

function updateCart() {
  const cartItemsDiv = document.getElementById('cart-items');
  const totalItemsSpan = document.getElementById('total-items');
  const totalCostSpan = document.getElementById('total-cost');
  const cartIcon = document.getElementById('cart-icon');

  cartItemsDiv.innerHTML = ''; // Clear current cart items
  let totalItems = 0;
  let totalCost = 0;

  cart.forEach(item => {
    totalItems += item.quantity;
    totalCost += item.price * item.quantity;

    cartItemsDiv.innerHTML += `
      <div class="cart-item">
        <span>${item.name}</span>
        <span>$${item.price}</span>
        <span>Qty: ${item.quantity}</span>
        <button onclick="increaseQuantity('${item.name}')">+</button>
        <button onclick="decreaseQuantity('${item.name}')">-</button>
        <button onclick="deleteItem('${item.name}')">Delete</button>
      </div>
    `;
  });

  totalItemsSpan.textContent = totalItems;
  totalCostSpan.textContent = totalCost.toFixed(2);
  cartIcon.textContent = `🛒 Cart (${totalItems})`;
}

function increaseQuantity(productName) {
  const product = cart.find(item => item.name === productName);
  if (product) product.quantity++;
  updateCart();
}

function decreaseQuantity(productName) {
  const product = cart.find(item => item.name === productName);
  if (product && product.quantity > 1) {
    product.quantity--;
  } else {
    deleteItem(productName);
  }
  updateCart();
}

function deleteItem(productName) {
  cart = cart.filter(item => item.name !== productName);
  updateCart();
}

function checkout() {
  alert('Coming Soon!');
}
function goToPage(page) {
  const productsPage = document.getElementById('products-page');
  const cartPage = document.getElementById('cart-page');

  if (page === 'products') {
    productsPage.style.display = 'block';
    cartPage.style.display = 'none';
  } else if (page === 'cart') {
    productsPage.style.display = 'none';
    cartPage.style.display = 'block';
  }
}
